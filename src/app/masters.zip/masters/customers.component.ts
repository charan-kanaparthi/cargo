import { Component ,Directive,Input,OnChanges,SimpleChanges, OnInit,Renderer,ViewChild,Inject,NgZone,SecurityContext,ElementRef} from '@angular/core';
import { Headers, Http, RequestOptions  } from '@angular/http';
import { NgForm } from '@angular/forms';
import { Router }  from '@angular/router';
import{MastersService} from './masters.service';
// import {UPLOAD_DIRECTIVES} from 'ng2-file-uploader/ng2-file-uploader';
import {Pipe, PipeTransform} from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Pipe({name: 'safeHtml'})
export class SafeHtml implements PipeTransform {
  constructor(private sanitizer:DomSanitizer, private elementRef:ElementRef){}
  transform(html) {
    
    return this.sanitizer.bypassSecurityTrustHtml(html);
  }
}


@Directive({selector: '[safeHtml]'})
export class HtmlDirective implements OnChanges {
  @Input() safeHtml:string;
  constructor(private sanitizer:DomSanitizer, private elementRef:ElementRef){}
  ngOnChanges(changes:SimpleChanges):any{
    if('safeHtml' in changes){
      this.elementRef.nativeElement.innerHTML=this.sanitizer.bypassSecurityTrustHtml(this.safeHtml);
    }

    
  }


}

export class Field
{
  name:string;
  id : string;
  type:string;
  label:string;
  isRequired:boolean;
  isReadOnly:boolean;
  isSelected:boolean;
  className :string;
  value:any;
  checkboxvalues:boolean[]=[];

  constructor(name:string,id:string,type:string,label:string,isRequired:boolean,isReadOnly:boolean,isSelected:boolean,className:string,value:string,checkboxvalues:boolean [])
  {
    this.name=name;
    this.id=id;
    this.type=type;
    this.label=label;
    this.isRequired=isRequired;
    this.isReadOnly=isReadOnly;
    this.isSelected=isSelected;
    this.className=className;
    this.value=value;
    this.checkboxvalues=checkboxvalues

  }
}

const urls=[
        "assets/myscripts/init.js"
    ];


 
@Component({
  templateUrl: 'customers.component.html',
 
})
export class CustomersComponent implements OnInit 
{
  fields:Field[]=[];
  theads:String[]=[];
  modalfields:Field[]=[];
  receivermodalfields:Field[]=[];
  deletemodalfields:Field[]=[];
  receiverEditModalFields:Field[]=[];
  selectedState=null;
  selectedTabledata=null;
  loadAPI:Promise<any>;
  isForm=true;
  checkboxFlag=[true,false,false];
  table_data:any[]=[];
  tfields=["Id","name","code"];
  tformFields=["name","code","select","radio","checkbox"];
  private zone: NgZone;

  private progress: number = 0;
  private response: any = {};

  ngOnInit()
  {
     this.getStates();
     this.loadScript();
   
  } 
  
  uploadFile: any;
  hasBaseDropZoneOver: boolean = false;
  options: Object = {
    url: 'http://http://172.16.32.54/project/public/uploads'
  };
  sizeLimit = 2000000;
 
  handleUpload(data): void {
    if (data && data.response) {
      data = JSON.parse(data.response);
      this.uploadFile = data;
      alert("DGR");
    }
  }
 
  fileOverBase(e:any):void {
    this.hasBaseDropZoneOver = e;
  }
 
  beforeUpload(uploadingFile): void {
    if (uploadingFile.size > this.sizeLimit) {
      uploadingFile.setAbort();
      alert('File is too large');
    }
  }

   public data;
   public file;
  constructor(private router: Router,private mastersService: MastersService,private http:Http,@Inject(Renderer) private renderer: Renderer) 
  {
      var test={name:'idType',id:'select',type:'select',label:'Id Type',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',value:"option1",options:["option1","option2","option3"],checkboxvalues:null};
      this.fields.push(test);
      test={name:'idNo',id:'code',type:'number', value:'', label:'Id Number',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.fields.push(test);
      test={name:'name',id:'name',  value:'',type:'text',label:'Name',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.fields.push(test);
      test={name:'emailId',id:'emailId',  value:'',type:'text',label:'Email ID',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.fields.push(test);
      test={name:'mobileNumber',id:'mobileNumber',type:'number', value:'', label:'Mobile',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.fields.push(test);
      test={name:'landline',id:'landline',type:'number', value:'', label:'Landline',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.fields.push(test);
      test={name:'city',id:'name',  value:'',type:'text',label:'City',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.fields.push(test);
      test={name:'n',id:'n',  value:'',type:'text',label:'n',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.fields.push(test);  
      test={name:'block',id:'block',  value:'',type:'text',label:'Block',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.fields.push(test);
      test={name:'commune',id:'commune',  value:'',type:'text',label:'Commune',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.fields.push(test);
      test={name:'address',id:'address',  value:'',type:'text',label:'Address',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.fields.push(test);
      test={name:'tinNumber',id:'tinNumber',  value:'',type:'text',label:'Tin Number',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.fields.push(test);

      
      test={name:'name',id:'name',  value:'',type:'text',label:'Name',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.receiverEditModalFields.push(test);
      test={name:'code',id:'code',type:'text', value:'', label:'Code',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.receiverEditModalFields.push(test);
      test={name:'select',id:'select',type:'select',label:'Select',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',value:"option1",options:["option1","option2","option3"],checkboxvalues:[true,false,false]};
      this.receiverEditModalFields.push(test);
      test={name:'radio',id:'radio',type:'radio',label:'Radio',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',value:"option1",options:["option1","option2","option3"],checkboxvalues:null};
      this.receiverEditModalFields.push(test);
      test={name:'checkbox',id:'name',type:'checkbox',label:'Checkbox',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',value:"",options:["option1","option2","option3"], checkboxvalues:[true,false,false]};
      this.receiverEditModalFields.push(test);

      test={name:'name',id:'name',  value:'',type:'text',label:'Name',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.receivermodalfields.push(test);
      test={name:'code',id:'code',type:'text', value:'', label:'Code',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.receivermodalfields.push(test);


      var test={name:'idType',id:'select',type:'select',label:'Id Type',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',value:"option1",options:["option1","option2","option3"],checkboxvalues:null};
      this.receivermodalfields.push(test);
      test={name:'idNo',id:'code',type:'number', value:'', label:'Id number ',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.receivermodalfields.push(test);
      test={name:'name',id:'name',  value:'',type:'text',label:'Name',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.receivermodalfields.push(test);
      test={name:'emailId',id:'emailId',  value:'',type:'text',label:'Email ID',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.receivermodalfields.push(test);
      test={name:'mobileNumber',id:'mobileNumber',type:'number', value:'', label:'Mobile',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.receivermodalfields.push(test);
      test={name:'landline',id:'landline',type:'number', value:'', label:'Landline',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.receivermodalfields.push(test);
      test={name:'city',id:'name',  value:'',type:'text',label:'City',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.receivermodalfields.push(test);
      test={name:'n',id:'n',  value:'',type:'text',label:'n',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.receivermodalfields.push(test);  
      test={name:'block',id:'block',  value:'',type:'text',label:'Block',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.receivermodalfields.push(test);
      test={name:'commune',id:'commune',  value:'',type:'text',label:'Commune',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.receivermodalfields.push(test);
      test={name:'address',id:'address',  value:'',type:'text',label:'Address',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.receivermodalfields.push(test);
      test={name:'tinNumber',id:'tinNumber',  value:'',type:'text',label:'Tin Number',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null ,checkboxvalues:null};
      this.receivermodalfields.push(test);


      test={name:'name',id:'name', value:'',type:'text',label:'Name',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.modalfields.push(test);
      test={name:'code',id:'code',type:'text', value:'', label:'Code',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.modalfields.push(test);
      test={name:'Id',id:'Id',type:'hidden', value:'', label:'',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.modalfields.push(test);
      test={name:'operation',id:'text',type:'hidden',label:'', value:'update', isRequired:false,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.modalfields.push(test);
      test={name:'Id',id:'Id',type:'hidden', value:'', label:'',isRequired:true,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.deletemodalfields.push(test);
      test={name:'status',id:'status',type:'hidden',label:'', value:'delete', isRequired:false,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.deletemodalfields.push(test);
      test={name:'operation',id:'text',type:'hidden',label:'', value:'update', isRequired:false,isReadOnly:false,isSelected:false,className:'form-control',options:null,checkboxvalues:null};
      this.deletemodalfields.push(test);
      this.theads.push('Id','Name','Code','Action'); 

    
  }
     files: FileList; 
     filestring: string; 
      deleteRow(row:any){
        alert(row.name);
        var j=0;
        for( var i in this.table_data){
            if(this.table_data[i].name==row.name){
              this.table_data.splice(j,1);
            }
             j++;
            }
           
      }

      editRow(form:NgForm){
        alert(JSON.stringify(form.value));
          var j=0 
          for( var i in this.table_data){
            if(this.table_data[i].name==form.value.name){
              alert(this.table_data[i].name)
                 alert(form.value.name)
                 alert(j)
                  this.table_data.splice(j,1,form.value);      
                  break;
               }
               j++;
            }
            
      }
      getFiles(event) { 
        alert("hii");
        this.files = event.target.files; 
        var reader = new FileReader(); 
         let file : File = this.files.item(0);
         this.file = file.name;
        reader.onload = this._handleReaderLoaded.bind(this); 
        reader.readAsBinaryString(this.files[0]); 
    } 
 
    _handleReaderLoaded(readerEvt) { 
        var binaryString = readerEvt.target.result; 
        this.filestring = btoa(binaryString); 
        alert(this.filestring);
        console.log(this.filestring); // Converting binary string data. 
   }  

 public onSelect(item:any)
  { 
     this.selectedState=item; 
      for( var i in this.modalfields){

        if(this.modalfields[i].name=="name"){
          this.modalfields[i].value=this.selectedState.name;
        }
        if(this.modalfields[i].name=="code"){
          this.modalfields[i].value=this.selectedState.code;
        }
          if(this.modalfields[i].name=="Id"){
            this.modalfields[i].value=this.selectedState.Id;
            this.deletemodalfields[0].value=this.selectedState.Id;
           }

    }
  }
  

  public onSelectReciever(item:any)
     {   var checkvalue="";
       alert(item.checkbox0);
      this.selectedTabledata=item; 
      for (let ref of this.receiverEditModalFields) {
           for(let tff of this.tformFields){ 

            if(ref['name']==tff && ref['name']!='checkbox' ){
                 alert(ref['name'])
              ref.value=this.selectedTabledata[tff];
             }

            if(ref['name']=='checkbox' ){
                var k=0
                for(let opt of ref['options']){
                  if(item['checkbox'+k]){
                     checkvalue+=opt
                     this.checkboxFlag[k]=item['checkbox'+k];
                  }
                  k++;
                }
            }
      }
      } 
     } 
  


  getStates() 
  {
    this.mastersService.getData("states").subscribe((data)=>{setTimeout(()=>{this.data=data}, 2000)});
  }

  public loadScript() 
  {
        console.log('preparing to load...')
        urls.forEach(function(url) 
        {   
          let node = document.createElement('script');
          node.src = url;
          node.type = 'text/javascript';
          node.async = true;
          node.charset = 'utf-8';
          document.getElementsByTagName('body')[0].appendChild(node);
        });
    }

  public items:Array<string> = ['Hyderabad','Chennai','Bengaluru','Vizag','Kakinada'];

  public value:any = ['Hyderabad'];

   public selected(value:any):void {
    console.log('Selected value is: ', value);
  }

  public removed(value:any):void {
    console.log('Removed value is: ', value);
  }

  public refreshValue(value:any):void {
    this.value = value;
  }

public  reciverdata(form:NgForm){
   alert(JSON.stringify(form.value));
   this.table_data.push(form.value); 
   
}

  public itemsToString(value:Array<any> = []):string {
    return value
      .map((item:any) => {
        return item.text;
      }).join(',');
  }
  showModal(){
    alert("in show modal");
    //editModal.show()
  }

  onSubmit(form:NgForm) 
  { 
      alert(JSON.stringify(form.value));
       // console.log(this.files); 
      //  this.sendValues("15","15");
        //this.mastersService.addfile("15","15",this.filestring,this.file );
         this.table_data.push(form.value);
      this.mastersService.add(this.table_data,"states");
  }
  

  onUpdate(upform:NgForm) 
  {  
      //this.selectedState=state;
      alert("in uoda");
      alert(JSON.stringify(upform.value));
      this.mastersService.update(upform.value,"states");
  }
}
